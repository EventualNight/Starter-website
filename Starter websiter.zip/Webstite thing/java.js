// Assuming this is java.js based on your script tag reference
function klik() {
    window.open("https://sites.google.com/view/gdmacromarketplace/home");
}